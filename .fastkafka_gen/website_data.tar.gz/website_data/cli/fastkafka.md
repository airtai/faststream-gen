# `fastkafka`

**Usage**:

```console
$ fastkafka [OPTIONS] COMMAND [ARGS]...
```

**Options**:

* `--install-completion`: Install completion for the current shell.
* `--show-completion`: Show completion for the current shell, to copy it or customize the installation.
* `--help`: Show this message and exit.

**Commands**:

* `code_generator`: Commands for accelerating FastKafka app creation using advanced AI technology
* `docs`: Commands for managing FastKafka app...
* `run`: Runs Fast Kafka API application
* `testing`: Commands for managing FastKafka testing

## `fastkafka code_generator`

Commands for accelerating FastKafka app creation using advanced AI technology.

These commands use a combination of OpenAI's gpt-3.5-turbo and gpt-3.5-turbo-16k models to generate FastKafka code. To access this feature, kindly sign up if you haven't already and create an API key with OpenAI. You can generate API keys in the OpenAI web interface. See https://platform.openai.com/account/api-keys for details.

Once you have the key, please set it in the OPENAI_API_KEY environment variable before executing the code generation commands.

Note: Accessing OpenAI API incurs charges. However, when you sign up for the first time, you usually get free credits that are more than enough to generate multiple FastKafka applications. For further information on pricing and free credicts, check this link: https://openai.com/pricing
    

**Usage**:

```console
$ fastkafka code_generator [OPTIONS] COMMAND [ARGS]...
```

**Options**:

* `--help`: Show this message and exit.

**Commands**:

* `generate`: Generate a new FastKafka app(s)...

### `fastkafka code_generator generate`

Generate a new FastKafka app(s) effortlessly with advanced AI assistance

**Usage**:

```console
$ fastkafka code_generator generate [OPTIONS] DESCRIPTION
```

**Arguments**:

* `DESCRIPTION`: Summarize your FastKafka app in a few sentences!



Include details about message classes, FastKafka app configuration (e.g., kafka_brokers), consumer and producer functions, and specify the business logic to be implemented. 



The simpler and more specific the app description is, the better the generated app will be. Please refer to the below example for inspiration:



Create a FastKafka application that consumes messages from the "store_product" topic. These messages should have three attributes: "product_name," "currency," and "price". While consuming, the app needs to produce a message to the "change_currency" topic. The function responsible for producing should take a "store_product" object as input and return the same object. Additionally, this function should check if the currency in the input "store_product" is "HRK." If it is, then the currency should be changed to "EUR," and the price should be divided by 7.5. Remember, the app should use a "localhost" broker.



  [required]

**Options**:

* `--help`: Show this message and exit.

## `fastkafka docs`

Commands for managing FastKafka app documentation

**Usage**:

```console
$ fastkafka docs [OPTIONS] COMMAND [ARGS]...
```

**Options**:

* `--help`: Show this message and exit.

**Commands**:

* `generate`: Generates documentation for a FastKafka...
* `install_deps`: Installs dependencies for FastKafka...
* `serve`: Generates and serves documentation for a...

### `fastkafka docs generate`

Generates documentation for a FastKafka application

**Usage**:

```console
$ fastkafka docs generate [OPTIONS] APP
```

**Arguments**:

* `APP`: input in the form of 'path:app', where **path** is the path to a python file and **app** is an object of type **FastKafka**.  [required]

**Options**:

* `--root-path TEXT`: root path under which documentation will be created; default is current directory
* `--help`: Show this message and exit.

### `fastkafka docs install_deps`

Installs dependencies for FastKafka documentation generation

**Usage**:

```console
$ fastkafka docs install_deps [OPTIONS]
```

**Options**:

* `--help`: Show this message and exit.

### `fastkafka docs serve`

Generates and serves documentation for a FastKafka application

**Usage**:

```console
$ fastkafka docs serve [OPTIONS] APP
```

**Arguments**:

* `APP`: input in the form of 'path:app', where **path** is the path to a python file and **app** is an object of type **FastKafka**.  [required]

**Options**:

* `--root-path TEXT`: root path under which documentation will be created; default is current directory
* `--bind TEXT`: Some info  [default: 127.0.0.1]
* `--port INTEGER`: Some info  [default: 8000]
* `--help`: Show this message and exit.

## `fastkafka run`

Runs Fast Kafka API application

**Usage**:

```console
$ fastkafka run [OPTIONS] APP
```

**Arguments**:

* `APP`: input in the form of 'path:app', where **path** is the path to a python file and **app** is an object of type **FastKafka**.  [required]

**Options**:

* `--num-workers INTEGER`: Number of FastKafka instances to run, defaults to number of CPU cores.  [default: 64]
* `--kafka-broker TEXT`: kafka_broker, one of the keys of the kafka_brokers dictionary passed in the constructor of FastaKafka class.  [default: localhost]
* `--help`: Show this message and exit.

## `fastkafka testing`

Commands for managing FastKafka testing

**Usage**:

```console
$ fastkafka testing [OPTIONS] COMMAND [ARGS]...
```

**Options**:

* `--help`: Show this message and exit.

**Commands**:

* `install_deps`: Installs dependencies for FastKafka app...

### `fastkafka testing install_deps`

Installs dependencies for FastKafka app testing

**Usage**:

```console
$ fastkafka testing install_deps [OPTIONS]
```

**Options**:

* `--help`: Show this message and exit.

